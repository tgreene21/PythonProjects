# import smtplib
#
# my_email = "greenpytest@gmail.com"
# password = "dgrj anoe uskg ulna"
#
# with smtplib.SMTP("smtp.gmail.com") as connection:
#     connection.starttls()
#     connection.login(user = my_email, password = password)
#     connection.sendmail(from_addr = my_email,
#                         to_addrs="tlg1234521@gmail.com",
#                         msg="Subject:Hello\n\n This is the subject of my email")

# import datetime as dt
#
# now = dt.datetime.now()
# year = now.year
# month = now.month
# day_of_week = now.weekday()
# print(day_of_week)
#
# date_of_birth = dt.datetime(year = 1995, month =12, day =15, hour = 4)
# print(date_of_birth)

import smtplib
import datetime as dt
import random

now = dt.datetime.now()
current_day = now.weekday()



#If current day is a Friday, send the email
if current_day == 4:
    with open("quotes.txt", 'r') as file:
        quotes = file.readlines()

    my_email = "greenpytest@gmail.com"
    password = "dgrj anoe uskg ulna"

    with smtplib.SMTP("smtp.gmail.com") as connection:
        connection.starttls()
        connection.login(user = my_email, password = password)
        connection.sendmail(from_addr = my_email,
                            to_addrs="tlg1234521@gmail.com",
                            msg=f"Subject:Quote of the Day!\n\n{random.choice(quotes)}")