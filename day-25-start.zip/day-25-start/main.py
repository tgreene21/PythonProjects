# with open("weather_data.csv") as file:
#     data = file.readlines()
#
# print(data)
import pandas

# import csv
#
# with open("weather_data.csv") as data_file:
#     data = csv.reader(data_file)
#     temperature = []
#     i = 0
#     for row in data:
#         if i > 0:
#          temperature.append(int(row[1]))
#         i += 1
#
# print(temperature)

# import pandas
#
# data = pandas.read_csv("weather_data.csv")
# #print(type(data))
# print(data["temp"])
#
# data_dict = data.to_dict()
# print(data_dict)
#
# temp_list = data["temp"].to_list()
# print(len(temp_list))

# sum = 0
# divisor = 0
#
# for temp in temp_list:
#     sum += temp
#     divisor += 1
#
# average = int(sum/divisor)

# average = sum(temp_list) / len(temp_list)

# average = data["temp"].mean()
# print(average)
#
# maximum = data["temp"].max()
# print(maximum)
#
# #Get Data in columns
# print(data["condition"])
# print(data.condition)

#Get Data in columns
# print(data[data["day"] == "Monday"])

#Print Row of Data which had the highest temperature
# max_row = data["temp"].idxmax()
# print(data.loc[max_row])
#
# monday = data[data.day == "Monday"]
# print(monday.condition)
#
# temp_c = monday.temp
# temp_f = (temp_c * (9/5)) + 32
# print(temp_f)

#Create a dataframe from scratch

data_dict = {
    "students":["Amy", "Bob"],
    "scores": [70, 80]
}

data = pandas.DataFrame(data_dict)
data.to_csv("new_data")
print(data)